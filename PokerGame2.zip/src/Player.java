import java.util.Arrays;
public class Player {

	public Card hand[];

	public String name;

	public Player(String playerName){
		name = playerName;
		hand = new Card[5];
	}

	public void Discard(int x){
		hand[x].isUsed = false;
		hand[x] = null;
	}

	public void DiscardAll(){
		for (int i = 0; i < 5; i++)
			Discard(i);
	}

	public void Draw(Card c){
		for (int i=0; i < 5; i++) {
			if (hand[i]==null){
				hand[i]= c;
				break;
			}
		}
	}

	public void GetCardList(String cards) {
		cards = new String();

		for (int i = 0; i < 5; i++) {
			if (hand[i] != null) {
				cards += hand[i].toString() + " ";
				break;
			}
		}
	}

	public int GetScore() {
		int score = 0;

		for (int i = 0; i < 5; i++) {
			if (hand[i] != null) {
				score += hand[i].number;
			}
		}

		return score;
	}
}

