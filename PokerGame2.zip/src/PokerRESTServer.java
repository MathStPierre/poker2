//package com.mcnz.restful.java.example;

import javax.ws.rs.*;

@ApplicationPath("/")
public class PokerRESTServer {


    // localhost:8080/pokerrestserver/creategame?name=mygame
    @PUT
    @Path("/creategame")
    @Produces("text/plain")
    public String createGame(@QueryParam("name") String name) {

        return currentGames.Create(name).toString();
    }

    // localhost:8080/pokerrestserver/deletegame?name=mygame
    @PUT
    @Path("/deletegame")
    @Produces("text/plain")
    public String deleteGame(@QueryParam("name") String name) {

        return currentGames.Delete(name).toString();
    }


    // localhost:8080/pokerrestserver/addplayer?gamename=mygame;playername=myplayer
    @PUT
    @Path("/addplayer")
    @Produces("text/plain")
    public String addPlayer(@QueryParam("gamename") String gamename,
                             @QueryParam("playername") String playername) {

        Game game = null;

        if (!currentGames.GetGame(gamename, game)) {

            return new String("ERROR : Game Not Found!");
        }


        //Improvement : add check for 2 players with same name, possibly returns unique ID.
        game.AddPlayer(playername);

        return new String("SUCCESS : Player Added!");
    }

    // localhost:8080/pokerrestserver/removeplayer?gamename=mygame;playername=myplayer
    @PUT
    @Path("/removeplayer")
    @Produces("text/plain")
    public String removePlayer(@QueryParam("gamename") String gamename,
                               @QueryParam("playername") String playername) {

        Game game = null;

        if (!currentGames.GetGame(gamename, game)) {

            return new String("ERROR : Game Not Found!");
        }

        if (!game.RemovePlayer(playername)) {

            return new String("ERROR : Player Not Found!");
        }


        return new String("SUCCESS : Player Removed!");
    }


    // localhost:8080/pokerrestserver/rungame?gamename=mygame
    @GET
    @Path("/rungame")
    @Produces("text/plain")
    public String rungame(@QueryParam("gamename") String gamename) {

        Game game = null;

        if (!currentGames.GetGame(gamename, game)) {

            return new String("ERROR : Game Not Found!");
        }

        if (game.players.size() < 2)
        {
            return new String("ERROR : Need at least 2 players!");
        }

        if (!game.RunGame()) {

            return new String("ERROR : Games cannot be run!");
        }

        return new String("SUCCESS : Game has been run!");
    }


    // localhost:8080/pokerrestserver/getcard?gamename=mygame;playername=myplayer
    @GET
    @Path("/getcard")
    @Produces("text/plain")
    public String getCard(@QueryParam("gamename") String gamename,
                          @QueryParam("playername") String playername) {

        Game game = null;

        if (!currentGames.GetGame(gamename, game)) {

            return new String("ERROR : Game Not Found!");
        }

        Player player = null;

        if (!game.GetPlayer(playername, player)) {

            return new String("ERROR : Player Not Found!");
        }


        String cardList = null;

        player.GetCardList(cardList);

        return cardList;
    }


    // localhost:8080/pokerrestserver/getresults?gamename=mygame
    @GET
    @Path("/getresults")
    @Produces("text/plain")
    public String getResults(@QueryParam("gamename") String gamename) {

        Game game = null;

        if (!currentGames.GetGame(gamename, game)) {

            return new String("ERROR : Game Not Found!");
        }

        String gameResults = null;

        game.GetGameResults(gameResults);

        return gameResults;
    }


    // localhost:8080/pokerrestserver/getundealtcardspersuite?gamename=mygame
    @GET
    @Path("/getundealtcardspersuite")
    @Produces("text/plain")
    public String getUndealtCardsPerSuite(@QueryParam("gamename") String gamename) {

        Game game = null;

        if (!currentGames.GetGame(gamename, game)) {

            return new String("ERROR : Game Not Found!");
        }

        String undealtCardsPerSuite = null;
        game.GetUndealtCardsPerSuite(undealtCardsPerSuite);

        return undealtCardsPerSuite;
    }


    // localhost:8080/pokerrestserver/getundealtcards?gamename=mygame
    @GET
    @Path("/getundealtcards")
    @Produces("text/plain")
    public String getUndealtCards(@QueryParam("gamename") String gamename) {

        Game game = null;

        if (!currentGames.GetGame(gamename, game)) {

            return new String("ERROR : Game Not Found!");
        }

        String undealtCards = null;
        game.GetUndealtCards(undealtCards);

        return undealtCards;
    }



/*
    @POST @Path("/score/wins")@Produces("text/plain")
    public int increaseWins() {	return Score.WINS++; }

    @POST @Path("/score/ties")@Produces("text/plain")
    public int increaseTies() {	return Score.WINS++;}

    @POST @Path("/score/losses")@Produces("text/plain")
    public int increaseLosses() {return Score.LOSSES++;}

    @GET @Path("/score/wins")@Produces("text/plain")
    public int getWins() {return Score.WINS;}

    @GET @Path("/score/losses")@Produces("text/plain")
    public int getLosses() {return Score.LOSSES;}

    @GET @Path("/score/ties")@Produces("text/plain")
    public int getTies() {return Score.TIES;}
*/

    private static Games currentGames;

}

