import java.util.ArrayList;
import java.util.Arrays;
public class Games {
	public ArrayList<Game> currentGames;

	public Games(){

		currentGames = new ArrayList<Game>();
	}

	Boolean Create(String gameName)
	{
		for (int i = 0; i < currentGames.size(); i++)
		{
			if (currentGames.get(i).name == gameName)
				return false;
		}

		currentGames.add(new Game(gameName));
		return true;
	}

	Boolean Delete(String gameName)
	{
		for (int i = 0; i < currentGames.size(); i++)
		{
			if (currentGames.get(i).name == gameName) {
				currentGames.remove(i);
				return true;
			}
		}

		return false;
	}

	boolean GetGame(String gameName, Game game)
	{

		for (int i = 0; i < currentGames.size(); i++)
		{
			if (currentGames.get(i).name == gameName) {
				game = currentGames.get(i);
				return true;
			}
		}

		return false;
	}

}
