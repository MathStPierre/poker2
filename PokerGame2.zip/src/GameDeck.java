import java.util.LinkedList;
import java.util.Random;
import java.util.ArrayList;
import java.util.Arrays;


public class GameDeck {
	private ArrayList<Card> cards;
	private Random shuffler;
	private int topCardInd;
	public GameDeck(){
		shuffler = new Random();
		cards = new ArrayList<Card>(0);
		AddDeck();
	}

	public void AddDeck()
	{
		int nextPos = cards.size();
		cards.ensureCapacity(cards.size() + 52);

		for (int i = 0; i<4; i++){
			for (int j = 1; j<14; j++) {
				cards.add(nextPos++, new Card(j,i));
			}
		}

		Shuffle();
	}

	public int GetNumberCards()
	{
		return cards.size();
	}


	public void Shuffle(){

		shuffler.setSeed(System.currentTimeMillis());

		//Do a permutation on each cards of the GameDeck
		for (int cardInd = 0; cardInd < cards.size(); cardInd++)
		{
			int permutationInd = shuffler.nextInt(cards.size());
			Card permutedCard = cards.get(cardInd);
			cards.set(cardInd, cards.get(permutationInd));
			cards.set(permutationInd, permutedCard);
		}

		topCardInd = 0;
	}

	public Boolean GetNextCard(Card card){


		for (int currentInd = topCardInd; currentInd < cards.size(); currentInd++)
		{
			if (cards.get(currentInd).isUsed == false) {
				cards.get(currentInd).isUsed = true;
				card = cards.get(currentInd);
				topCardInd = currentInd;
				return true;
			}
		}

		for (int currentInd = 0; currentInd < topCardInd; currentInd++)
		{
			if (cards.get(currentInd).isUsed == false) {
				cards.get(currentInd).isUsed = true;
				card = cards.get(currentInd);
				topCardInd = currentInd;
				return true;
			}
		}

		return false;

	}

	public void GetUndealtCardStat(ArrayList<ArrayList<Integer>> undealtCards)
	{
		undealtCards.ensureCapacity(4);

		for (int i = 0; i < 4; i++)
		{
			undealtCards.add(new ArrayList<Integer>(13));

			for (int j = 0; j < 13; i++)
			{
				undealtCards.get(i).add(0);
			}
		}

		for (Card c: cards)
		{
			if (c.isUsed == false)
			{
				undealtCards.get(c.suite).set(c.number, undealtCards.get(c.suite).get(c.number) + 1);
			}
		}

	}
}