import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;


class PlayerComparator implements Comparator<Player> {
	@Override
	public int compare(Player a, Player b) {
		return a.GetScore() > b.GetScore() ? -1 : a.GetScore() == b.GetScore() ? 0 : 1;
	}
}


public class Game {

	public static int NB_CARDS = 5;
	public ArrayList<Player> players;
	public GameDeck deck;
	public String name;


	public Game(String gameName){
		name = gameName;
		deck = new GameDeck();
		players = new ArrayList<Player>();
	}

	void AddPlayer(String playerName)
	{
		players.add(new Player(playerName));
	}

	Boolean RemovePlayer(String playerName)
	{
		for (int i = 0; i < players.size(); i++)
		{
			if (players.get(i).name == playerName) {
				players.get(i).DiscardAll();
				players.remove(i);
				return true;
			}
		}

		return false;
	}

	Boolean GetPlayer(String playerName, Player player)
	{
		for (int i = 0; i < players.size(); i++)
		{
			if (players.get(i).name == playerName) {
				player = players.get(i);
				return true;
			}
		}

		return false;
	}


	//public AddDeck()

	//Simple game, deal 5 cards to each player.
	public Boolean RunGame(){
		// Not enough cards for all players.
		if (players.size() * NB_CARDS > deck.GetNumberCards())
			return false;

		for (Player p: players)
		{
			for (int i = 0; i < NB_CARDS; i++) {
				Card card = null;
				if (deck.GetNextCard(card)) {
					p.Draw(card);
				}
			}
		}

		return true;
		}


	public void GetGameResults(String gameResults) {

		gameResults = new String();

		Collections.sort(players, new PlayerComparator());

		for (Player p: players)
		{
			gameResults += p.name + " " + Integer.toString(p.GetScore()) + " \r\n";
		}

		}


	public void GetUndealtCardsPerSuite(String undealtCardsPerSuite) {

		undealtCardsPerSuite = new String();
		ArrayList<ArrayList<Integer>> undealtCards = null;

		deck.GetUndealtCardStat(undealtCards);

		for (int suite = 0; suite < 4; suite++)
		{
			int nbCardsForSuite = 0;

			for (int j = 0; j < 13; j++)
			{
				nbCardsForSuite += undealtCards.get(suite).get(j);
			}

			switch (suite){
				case(0): undealtCardsPerSuite+="H "; break;
				case(1): undealtCardsPerSuite+="S "; break;
				case(2): undealtCardsPerSuite+="C "; break;
				case(3): undealtCardsPerSuite+="D "; break;
			}

			undealtCardsPerSuite += Integer.toString(nbCardsForSuite) + " \r\n";
		}
	}



	public void GetUndealtCards(String undealtCardsList) {

		undealtCardsList = new String();
		ArrayList<ArrayList<Integer>> undealtCards = null;

		deck.GetUndealtCardStat(undealtCards);

		for (int suite = 0; suite < 4; suite++)
		{
			for (int j = 13; j < 0; j--)
			{
				switch (suite) {
					case (0):
						undealtCardsList += "H ";
						break;
					case (1):
						undealtCardsList += "S ";
						break;
					case (2):
						undealtCardsList += "C ";
						break;
					case (3):
						undealtCardsList += "D ";
						break;
				}

				undealtCardsList += Integer.toString(j);
				undealtCardsList += Integer.toString(undealtCards.get(suite).get(j)) + " | ";
			}
		}
	}

}